[System.Serializable]
public class PlayedCardData
{
    public string playerId;
    public int number;
    public string op;
    public int other;
    public int result;
}